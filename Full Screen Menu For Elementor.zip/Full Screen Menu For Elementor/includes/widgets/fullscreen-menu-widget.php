<?php
/**
 * Fullscreen Menu Widget.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Elementor Fullscreen Menu Widget.
 */
class Elementor_Fullscreen_Menu_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'fullscreen_menu';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Full Screen Menu', 'elementor-fullscreen-menu' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-menu-bar';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'general' ];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'menu', 'fullscreen', 'navigation', 'nav' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {

        // Icon Settings
        $this->start_controls_section(
            'section_icon',
            [
                'label' => esc_html__( 'Icon Settings', 'elementor-fullscreen-menu' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'icon_size',
            [
                'label'   => esc_html__( 'Icon Size', 'elementor-fullscreen-menu' ),
                'type'    => \Elementor\Controls_Manager::SLIDER,
                'range'   => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .fullscreen-menu-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => esc_html__( 'Icon Color', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .fullscreen-menu-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'icon_border',
                'selector' => '{{WRAPPER}} .fullscreen-menu-icon',
            ]
        );

        $this->add_responsive_control(
            'icon_padding',
            [
                'label'      => esc_html__( 'Padding', 'elementor-fullscreen-menu' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .fullscreen-menu-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_alignment',
            [
                'label'     => esc_html__( 'Alignment', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'flex-start' => [
                        'title' => esc_html__( 'Left', 'elementor-fullscreen-menu' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'     => [
                        'title' => esc_html__( 'Center', 'elementor-fullscreen-menu' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'flex-end'   => [
                        'title' => esc_html__( 'Right', 'elementor-fullscreen-menu' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'   => 'center',
                'selectors' => [
                    '{{WRAPPER}} .fullscreen-menu-container' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Menu Content
        $this->start_controls_section(
            'section_menu_content',
            [
                'label' => esc_html__( 'Menu Content', 'elementor-fullscreen-menu' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'content_type',
            [
                'label'   => esc_html__( 'Content Type', 'elementor-fullscreen-menu' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'menu',
                'options' => [
                    'menu'     => esc_html__( 'WordPress Menu', 'elementor-fullscreen-menu' ),
                    'template' => esc_html__( 'Elementor Template', 'elementor-fullscreen-menu' ),
                ],
            ]
        );

        $menus = wp_get_nav_menus();
        $menu_options = [];
        
        foreach ( $menus as $menu ) {
            $menu_options[ $menu->term_id ] = $menu->name;
        }

        if (empty($menu_options)) {
            $menu_options[''] = esc_html__('No menus found', 'elementor-fullscreen-menu');
        }

        $this->add_control(
            'menu_select',
            [
                'label'     => esc_html__( 'Select Menu', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => $menu_options,
                'default'   => array_keys( $menu_options )[0] ?? '',
                'condition' => [
                    'content_type' => 'menu',
                ],
            ]
        );

        $templates = get_posts([
            'post_type'      => 'elementor_library',
            'posts_per_page' => -1,
        ]);
        
        $template_options = [];
        
        foreach ( $templates as $template ) {
            $template_options[ $template->ID ] = $template->post_title;
        }

        if (empty($template_options)) {
            $template_options[''] = esc_html__('No templates found', 'elementor-fullscreen-menu');
        }

        $this->add_control(
            'template_select',
            [
                'label'     => esc_html__( 'Select Template', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'options'   => $template_options,
                'default'   => array_keys( $template_options )[0] ?? '',
                'condition' => [
                    'content_type' => 'template',
                ],
            ]
        );

        $this->end_controls_section();

        // Overlay Style
        $this->start_controls_section(
            'section_overlay',
            [
                'label' => esc_html__( 'Overlay Style', 'elementor-fullscreen-menu' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'overlay_background',
            [
                'label'     => esc_html__( 'Background Color', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .fullscreen-menu-overlay' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Menu Style
        $this->start_controls_section(
            'section_menu_style',
            [
                'label'     => esc_html__( 'Menu Style', 'elementor-fullscreen-menu' ),
                'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'content_type' => 'menu',
                ],
            ]
        );

        $this->add_control(
            'menu_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .fullscreen-menu-overlay .menu a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'menu_text_hover_color',
            [
                'label'     => esc_html__( 'Text Hover Color', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#555555',
                'selectors' => [
                    '{{WRAPPER}} .fullscreen-menu-overlay .menu a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'menu_typography',
                'selector' => '{{WRAPPER}} .fullscreen-menu-overlay .menu a',
            ]
        );

        $this->add_responsive_control(
            'menu_spacing',
            [
                'label'     => esc_html__( 'Menu Item Spacing', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'   => [
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .fullscreen-menu-overlay .menu li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'menu_alignment',
            [
                'label'     => esc_html__( 'Menu Alignment', 'elementor-fullscreen-menu' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [
                        'title' => esc_html__( 'Left', 'elementor-fullscreen-menu' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'elementor-fullscreen-menu' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__( 'Right', 'elementor-fullscreen-menu' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'   => 'center',
                'selectors' => [
                    '{{WRAPPER}} .fullscreen-menu-overlay .menu' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $this->add_render_attribute( 'container', 'class', 'fullscreen-menu-container' );
        ?>
        <div <?php echo $this->get_render_attribute_string( 'container' ); ?>>
            <div class="fullscreen-menu-icon">
                <div class="burger-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            
            <div class="fullscreen-menu-overlay">
                <div class="close-icon">
                    <span></span>
                    <span></span>
                </div>
                
                <div class="fullscreen-menu-content">
                    <?php if ( $settings['content_type'] === 'menu' && !empty($settings['menu_select']) ) : ?>
                        <?php 
                        wp_nav_menu( array(
                            'menu'        => $settings['menu_select'],
                            'menu_class'  => 'menu',
                            'depth'       => 1,
                            'fallback_cb' => false,
                        ) ); 
                        ?>
                    <?php elseif ( $settings['content_type'] === 'template' && !empty($settings['template_select']) ) : ?>
                        <?php 
                        if (class_exists('\Elementor\Plugin')) {
                            echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $settings['template_select'], true );
                        } else {
                            echo esc_html__('Elementor is not active', 'elementor-fullscreen-menu');
                        }
                        ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
}