<?php
/*
Plugin Name: Full Screen Menu for Elementor
Description: A lightweight Elementor addon for a full-screen menu with an animated toggle button.
Version: 1.0
Author: ClarkeMedia.ie
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Enqueue CSS and JS
function fsme_enqueue_scripts() {
    // CSS
    wp_enqueue_style(
        'fsme-style',
        plugins_url('assets/style.css', __FILE__),
        [],
        '1.0'
    );

    // JavaScript
    wp_enqueue_script(
        'fsme-script',
        plugins_url('assets/script.js', __FILE__),
        ['jquery'], // Add jQuery as a dependency
        '1.0',
        true // Load in footer
    );
}
add_action('wp_enqueue_scripts', 'fsme_enqueue_scripts');

// Register the widget
function fsme_register_widget($widgets_manager) {
    require_once __DIR__ . '/widgets/class-fullscreen-menu-widget.php';
    $widgets_manager->register(new \Elementor_Fullscreen_Menu_Widget());
}
add_action('elementor/widgets/register', 'fsme_register_widget');