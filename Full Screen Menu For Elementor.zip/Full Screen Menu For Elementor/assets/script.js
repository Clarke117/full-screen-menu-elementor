jQuery(document).ready(function ($) {
    $('.fsme-burger').on('click', function () {
        $(this).toggleClass('active');
        $('.fsme-fullscreen-menu').toggleClass('active');
    });
});