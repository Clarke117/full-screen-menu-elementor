(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Toggle fullscreen menu - fixed selector relationship
        $('.fullscreen-menu-icon').on('click', function() {
            var $container = $(this).closest('.fullscreen-menu-container');
            var $overlay = $container.find('.fullscreen-menu-overlay');
            $overlay.addClass('active');
            $('body').addClass('menu-opened');
        });
        
        // Close fullscreen menu
        $('.close-icon').on('click', function() {
            var $overlay = $(this).closest('.fullscreen-menu-overlay');
            $overlay.removeClass('active');
            $('body').removeClass('menu-opened');
        });
        
        // Close menu when clicking on a menu item (optional)
        $('.fullscreen-menu-overlay .menu a').on('click', function() {
            var $overlay = $(this).closest('.fullscreen-menu-overlay');
            $overlay.removeClass('active');
            $('body').removeClass('menu-opened');
        });
        
        // Close menu on ESC key
        $(document).keyup(function(e) {
            if (e.key === "Escape") {
                $('.fullscreen-menu-overlay').removeClass('active');
                $('body').removeClass('menu-opened');
            }
        });
    });
    
})(jQuery);