<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Elementor_Fullscreen_Menu_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'fullscreen_menu';
    }

    public function get_title() {
        return __('Full Screen Menu', 'full-screen-menu-for-elementor');
    }

    public function get_icon() {
        return 'eicon-menu-bar';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function _register_controls() {
        // Content Tab
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'full-screen-menu-for-elementor'),
            ]
        );

        // Menu or Template Selector
        $this->add_control(
            'content_type',
            [
                'label' => __('Content Type', 'full-screen-menu-for-elementor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'menu' => __('Menu', 'full-screen-menu-for-elementor'),
                    'template' => __('Template', 'full-screen-menu-for-elementor'),
                ],
                'default' => 'menu',
            ]
        );

        // Menu Selector
        $this->add_control(
            'menu',
            [
                'label' => __('Select Menu', 'full-screen-menu-for-elementor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $this->get_available_menus(),
                'default' => '',
                'condition' => [
                    'content_type' => 'menu',
                ],
            ]
        );

        // Template Selector
        $this->add_control(
            'template_id',
            [
                'label' => __('Select Template', 'full-screen-menu-for-elementor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $this->get_available_templates(),
                'default' => '',
                'condition' => [
                    'content_type' => 'template',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab: Button
        $this->start_controls_section(
            'section_button_style',
            [
                'label' => __('Button Style', 'full-screen-menu-for-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Button Color
        $this->add_control(
            'button_color',
            [
                'label' => __('Button Color', 'full-screen-menu-for-elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .fsme-burger span' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // Button Size
        $this->add_control(
            'button_size',
            [
                'label' => __('Button Size', 'full-screen-menu-for-elementor'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 40,
                ],
                'selectors' => [
                    '{{WRAPPER}} .fsme-burger' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .fsme-burger span' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // Button HTML
        echo '<div class="fsme-burger-wrapper">';
        echo '<div class="fsme-burger">
            <span></span>
            <span></span>
            <span></span>
        </div>';
        echo '</div>';

        // Fullscreen Menu
        echo '<div class="fsme-fullscreen-menu">';
        if ($settings['content_type'] === 'template' && !empty($settings['template_id'])) {
            // Display Elementor template
            echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($settings['template_id']);
        } elseif ($settings['content_type'] === 'menu' && !empty($settings['menu'])) {
            // Display WordPress menu
            wp_nav_menu([
                'menu' => $settings['menu'],
                'menu_class' => 'fsme-menu',
            ]);
        } else {
            echo __('No content selected.', 'full-screen-menu-for-elementor');
        }
        echo '</div>';
    }

    private function get_available_menus() {
        $menus = wp_get_nav_menus();
        $options = [];

        foreach ($menus as $menu) {
            $options[$menu->term_id] = $menu->name;
        }

        return $options;
    }

    private function get_available_templates() {
        $templates = get_posts([
            'post_type' => 'elementor_library',
            'posts_per_page' => -1,
            'post_status' => 'publish',
        ]);

        $options = ['' => __('Select Template', 'full-screen-menu-for-elementor')];

        foreach ($templates as $template) {
            $options[$template->ID] = $template->post_title;
        }

        return $options;
    }
}